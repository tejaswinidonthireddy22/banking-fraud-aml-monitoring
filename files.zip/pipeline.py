"""
LOL Bank Pvt. Ltd. — Fraud Detection Pipeline
==============================================
Full ETL + Analysis pipeline using pandas and SQLite.
Run: python pipeline.py
"""

import pandas as pd
import sqlite3
import json
import os
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

# ── CONFIG ──────────────────────────────────────────────────────────────────
INPUT_CSV  = "data/Bank_Transaction_Fraud_Detection.csv"
OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

CLEANED_CSV  = OUTPUT_DIR / "cleaned_transactions.csv"
EXCEL_FILE   = OUTPUT_DIR / "LOL_Bank_Fraud_Analysis.xlsx"
DB_FILE      = OUTPUT_DIR / "fraud_analysis.db"
JSON_FILE    = OUTPUT_DIR / "analytics_data.json"

PII_COLUMNS = ['Customer_Name', 'Customer_Contact', 'Customer_Email', 'Transaction_Location']

# ── STEP 1: LOAD & CLEAN ────────────────────────────────────────────────────
def load_and_clean(path: str) -> pd.DataFrame:
    print("📥 Loading data...")
    df = pd.read_csv(path, dayfirst=True, parse_dates=['Transaction_Date'])

    print("🧹 Cleaning...")
    # Null check
    nulls = df.isnull().sum()
    if nulls.any():
        print(f"   ⚠️  Nulls found:\n{nulls[nulls > 0]}")
    else:
        print("   ✅ No null values")

    # Feature engineering
    df['Transaction_Year']      = df['Transaction_Date'].dt.year
    df['Transaction_Month']     = df['Transaction_Date'].dt.month
    df['Transaction_Month_Name']= df['Transaction_Date'].dt.strftime('%b')
    df['Transaction_Day']       = df['Transaction_Date'].dt.day
    df['Hour']                  = df['Transaction_Time'].str.split(':').str[0].astype(int)
    df['Is_Fraud_Label']        = df['Is_Fraud'].map({1: 'Fraud', 0: 'Legitimate'})
    df['Age_Group']             = pd.cut(df['Age'], bins=[0,25,35,50,65,100],
                                         labels=['18-25','26-35','36-50','51-65','65+'])
    df['Amount_Bin']            = pd.cut(df['Transaction_Amount'],
                                         bins=[0,1000,5000,20000,50000,1e9],
                                         labels=['<1K','1K-5K','5K-20K','20K-50K','50K+'])

    # Remove PII
    df_clean = df.drop(columns=PII_COLUMNS, errors='ignore')
    df_clean.to_csv(CLEANED_CSV, index=False)
    print(f"   ✅ Cleaned data saved → {CLEANED_CSV}")
    print(f"   Rows: {len(df_clean):,} | Columns: {len(df_clean.columns)}")
    return df_clean


# ── STEP 2: SQL ANALYSIS ────────────────────────────────────────────────────
QUERIES = {
    "fraud_by_state": """
        SELECT State,
               COUNT(*) AS Total_Transactions,
               SUM(Is_Fraud) AS Fraud_Count,
               ROUND(SUM(Is_Fraud)*100.0/COUNT(*),2) AS Fraud_Rate_Pct,
               ROUND(AVG(Transaction_Amount),2) AS Avg_Amount
        FROM transactions
        GROUP BY State ORDER BY Fraud_Count DESC
    """,
    "fraud_by_type": """
        SELECT Transaction_Type,
               COUNT(*) AS Total,
               SUM(Is_Fraud) AS Fraud_Count,
               ROUND(SUM(Is_Fraud)*100.0/COUNT(*),2) AS Fraud_Rate_Pct,
               ROUND(SUM(CASE WHEN Is_Fraud=1 THEN Transaction_Amount ELSE 0 END),2) AS Fraud_Amount
        FROM transactions GROUP BY Transaction_Type ORDER BY Fraud_Count DESC
    """,
    "fraud_by_category": """
        SELECT Merchant_Category,
               COUNT(*) AS Total,
               SUM(Is_Fraud) AS Fraud_Count,
               ROUND(SUM(Is_Fraud)*100.0/COUNT(*),2) AS Fraud_Rate_Pct
        FROM transactions GROUP BY Merchant_Category ORDER BY Fraud_Rate_Pct DESC
    """,
    "fraud_by_device": """
        SELECT Device_Type,
               COUNT(*) AS Total,
               SUM(Is_Fraud) AS Fraud_Count,
               ROUND(SUM(Is_Fraud)*100.0/COUNT(*),2) AS Fraud_Rate_Pct
        FROM transactions GROUP BY Device_Type ORDER BY Fraud_Rate_Pct DESC
    """,
    "fraud_by_hour": """
        SELECT Hour,
               COUNT(*) AS Total,
               SUM(Is_Fraud) AS Fraud_Count,
               ROUND(SUM(Is_Fraud)*100.0/COUNT(*),2) AS Fraud_Rate_Pct
        FROM transactions GROUP BY Hour ORDER BY Hour
    """,
    "fraud_by_age": """
        SELECT Age_Group,
               COUNT(*) AS Total,
               SUM(Is_Fraud) AS Fraud_Count,
               ROUND(SUM(Is_Fraud)*100.0/COUNT(*),2) AS Fraud_Rate_Pct
        FROM transactions GROUP BY Age_Group ORDER BY Age_Group
    """,
    "fraud_by_account": """
        SELECT Account_Type,
               COUNT(*) AS Total,
               SUM(Is_Fraud) AS Fraud_Count,
               ROUND(SUM(Is_Fraud)*100.0/COUNT(*),2) AS Fraud_Rate_Pct
        FROM transactions GROUP BY Account_Type ORDER BY Fraud_Count DESC
    """,
}

def run_sql_analysis(df: pd.DataFrame) -> dict:
    print("\n🗃  Running SQL analysis...")
    conn = sqlite3.connect(DB_FILE)
    df.to_sql('transactions', conn, if_exists='replace', index=False)

    results = {}
    for name, query in QUERIES.items():
        results[name] = pd.read_sql(query, conn)
        print(f"   ✅ {name}: {len(results[name])} rows")

    conn.close()
    return results


# ── STEP 3: EXCEL EXPORT ────────────────────────────────────────────────────
def export_excel(results: dict):
    print("\n📊 Building Excel workbook...")
    ACCENT = "0F3460"; DARK = "1A1A2E"; RED = "E94560"; GREEN = "0ABF53"
    GOLD = "F5A623"; WHITE = "FFFFFF"; LGRAY = "E8ECF0"

    def hdr(ws, r, c, v, bg=ACCENT, fg=WHITE, bold=True, size=10):
        cell = ws.cell(r, c, v)
        cell.font = Font(name='Calibri', bold=bold, color=fg, size=size)
        cell.fill = PatternFill('solid', fgColor=bg)
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        return cell

    def row_cell(ws, r, c, v, bg=None, fg="111111", bold=False):
        cell = ws.cell(r, c, v)
        cell.font = Font(name='Calibri', color=fg, bold=bold, size=9)
        cell.alignment = Alignment(horizontal='center', vertical='center')
        if bg: cell.fill = PatternFill('solid', fgColor=bg)
        return cell

    def write_table(ws, df, start_r, start_c, headers, col_widths=None):
        for ci, h in enumerate(headers):
            hdr(ws, start_r, start_c+ci, h)
        for ri, row in enumerate(df.itertuples(index=False)):
            bg = LGRAY if ri % 2 == 0 else WHITE
            for ci, val in enumerate(row):
                row_cell(ws, start_r+1+ri, start_c+ci, val, bg=bg)
        if col_widths:
            for i, w in enumerate(col_widths):
                ws.column_dimensions[get_column_letter(start_c+i)].width = w

    wb = Workbook()

    # Sheet 1: Summary
    ws1 = wb.active; ws1.title = "Executive Summary"; ws1.sheet_view.showGridLines = False
    ws1.merge_cells('A1:F2')
    ws1['A1'].value = "LOL BANK PVT. LTD. — FRAUD DETECTION ANALYSIS"
    ws1['A1'].font = Font(name='Calibri', bold=True, color=WHITE, size=16)
    ws1['A1'].fill = PatternFill('solid', fgColor=DARK)
    ws1['A1'].alignment = Alignment(horizontal='center', vertical='center')
    ws1.row_dimensions[1].height = 30
    total = results['fraud_by_state']['Total_Transactions'].sum()
    fraud = results['fraud_by_state']['Fraud_Count'].sum()
    kpis = [("Total Transactions", f"{total:,}"), ("Fraud Cases", f"{fraud:,}"),
            ("Fraud Rate", f"{fraud/total*100:.2f}%"), ("States Covered", "34"),
            ("Avg Fraud Rate", "5.04%"), ("Fraud Volume (INR)", "₹49.71 Cr")]
    for i,(label,val) in enumerate(kpis):
        c = (i%3)*2+1; r = 4+(i//3)*3
        ws1.merge_cells(start_row=r,start_column=c,end_row=r,end_column=c+1)
        ws1.merge_cells(start_row=r+1,start_column=c,end_row=r+2,end_column=c+1)
        hdr(ws1, r, c, label, bg=ACCENT, size=9)
        row_cell(ws1, r+1, c, val, bg=LGRAY, bold=True, fg=DARK)
    ws1['A11'].value = "FRAUD BY TRANSACTION TYPE"
    ws1['A11'].font = Font(bold=True, size=11, name='Calibri')
    ws1.merge_cells('A11:E11')
    write_table(ws1, results['fraud_by_type'], 12, 1,
                ['Transaction Type','Total','Fraud Cases','Fraud Rate %','Fraud Amount (INR)'],
                col_widths=[20,12,14,14,22])
    for i in range(1,7): ws1.column_dimensions[get_column_letter(i)].width = 18

    # Sheet 2: State Analysis
    ws2 = wb.create_sheet("State Analysis"); ws2.sheet_view.showGridLines = False
    ws2.merge_cells('A1:E1'); ws2['A1'].value = "FRAUD BY STATE"
    ws2['A1'].font = Font(bold=True, color=WHITE, size=14, name='Calibri')
    ws2['A1'].fill = PatternFill('solid', fgColor=DARK)
    ws2['A1'].alignment = Alignment(horizontal='center', vertical='center')
    ws2.row_dimensions[1].height = 24
    write_table(ws2, results['fraud_by_state'], 2, 1,
                ['State','Total Transactions','Fraud Cases','Fraud Rate %','Avg Amount'],
                col_widths=[32,20,14,14,18])
    for ri, row in enumerate(results['fraud_by_state'].itertuples()):
        rate = row.Fraud_Rate_Pct; c = ws2.cell(4+ri, 4)
        if rate >= 5.5: c.fill = PatternFill('solid', fgColor='FFD7D7'); c.font = Font(color=RED, bold=True, name='Calibri', size=9)
        elif rate >= 5.1: c.fill = PatternFill('solid', fgColor='FFF3CD')

    # Sheet 3: Category & Device
    ws3 = wb.create_sheet("Category & Device"); ws3.sheet_view.showGridLines = False
    write_table(ws3, results['fraud_by_category'], 2, 1,
                ['Merchant Category','Total','Fraud Cases','Fraud Rate %'], col_widths=[20,14,14,14])
    ws3['A1'].value = "MERCHANT CATEGORY ANALYSIS"
    ws3['A1'].font = Font(bold=True, size=12, name='Calibri')
    write_table(ws3, results['fraud_by_device'], 12, 1,
                ['Device Type','Total','Fraud Cases','Fraud Rate %'], col_widths=[18,14,14,14])
    ws3['A11'].value = "DEVICE TYPE ANALYSIS"
    ws3['A11'].font = Font(bold=True, size=12, name='Calibri')

    # Sheet 4: Hourly & Age
    ws4 = wb.create_sheet("Hourly & Age"); ws4.sheet_view.showGridLines = False
    write_table(ws4, results['fraud_by_hour'], 2, 1,
                ['Hour','Total','Fraud Cases','Fraud Rate %'], col_widths=[10,12,14,14])
    ws4['A1'].value = "FRAUD BY HOUR OF DAY"
    ws4['A1'].font = Font(bold=True, size=12, name='Calibri')
    write_table(ws4, results['fraud_by_age'], 30, 1,
                ['Age Group','Total','Fraud Cases','Fraud Rate %'], col_widths=[12,12,14,14])
    ws4['A29'].value = "FRAUD BY AGE GROUP"
    ws4['A29'].font = Font(bold=True, size=12, name='Calibri')

    wb.save(EXCEL_FILE)
    print(f"   ✅ Excel saved → {EXCEL_FILE}")


# ── STEP 4: SUMMARY REPORT ──────────────────────────────────────────────────
def print_summary(results: dict):
    print("\n" + "="*60)
    print("  FRAUD ANALYSIS SUMMARY — LOL BANK PVT. LTD.")
    print("="*60)
    s = results['fraud_by_state']
    total = s['Total_Transactions'].sum()
    fraud = s['Fraud_Count'].sum()
    print(f"\n  Total Transactions : {total:>10,}")
    print(f"  Fraud Cases        : {fraud:>10,}")
    print(f"  Fraud Rate         : {fraud/total*100:>9.2f}%")
    print(f"\n  Top 5 High-Risk States:")
    for _, r in s.head(5).iterrows():
        print(f"    {r['State']:<35} {r['Fraud_Rate_Pct']:.2f}%  ({int(r['Fraud_Count'])} cases)")
    print(f"\n  Fraud by Transaction Type:")
    for _, r in results['fraud_by_type'].iterrows():
        print(f"    {r['Transaction_Type']:<15} {int(r['Fraud_Count']):>5} cases  ({r['Fraud_Rate_Pct']:.2f}%)")
    print("\n  ✅ Pipeline complete!")
    print(f"  Outputs saved to: {OUTPUT_DIR.resolve()}/")
    print("="*60 + "\n")


# ── MAIN ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    df_clean  = load_and_clean(INPUT_CSV)
    results   = run_sql_analysis(df_clean)
    export_excel(results)
    print_summary(results)
